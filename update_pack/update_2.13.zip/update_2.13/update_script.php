<?php
$CI = get_instance();
$CI->load->database();
$CI->load->dbforge();


$count = $CI->db->get_where("frontend_settings", array("type" => "home_page"))->num_rows();

if ($count == 0) {

    $data['type'] = "home_page";
    $data['description'] = "1";
    $CI->db->insert('frontend_settings', $data);
}



//update data in settings table
$settings_datas['description'] = '2.13';
$CI->db->where('type', 'version');
$CI->db->update('settings', $settings_datas);
