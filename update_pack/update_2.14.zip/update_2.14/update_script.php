<?php
$CI = get_instance();
$CI->load->database();
$CI->load->dbforge();

//update data in settings table
$settings_datas['description'] = '2.14';
$CI->db->where('type', 'version');
$CI->db->update('settings', $settings_datas);
